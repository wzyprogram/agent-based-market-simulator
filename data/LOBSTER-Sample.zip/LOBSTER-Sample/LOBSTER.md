# LOBSTER data sample
## Message File:		(Matrix of size: (Nx6))
		
	Name: 	TICKER_Year-Month-Day_StartTime_EndTime_message_LEVEL.csv 	
		
		StartTime and EndTime give the theoretical beginning 
		and end time of the output file in milliseconds after 		
		mid night. LEVEL refers to the number of levels of the 
		requested limit order book.


	Columns:
	
	    1.) Time: 		
				Seconds after midnight with decimal 
				precision of at least milliseconds 
				and up to nanoseconds depending on 
				the requested period
	    2.) Type:
				1: Submission of a new limit order
				2: Cancellation (Partial deletion 
				   of a limit order)
				3: Deletion (Total deletion of a limit order)
				4: Execution of a visible limit order			   	 
				5: Execution of a hidden limit order
				7: Trading halt indicator 				   
				   (Detailed information below)
	    3.) Order ID: 	
				Unique order reference number 
				(Assigned in order flow)
	    4.) Size: 		
				Number of shares
	    5.) Price: 		
				Dollar price times 10000 
				(i.e., A stock price of $91.14 is given 
				by 911400)
	    6.) Direction:
				-1: Sell limit order
				1: Buy limit order
				
				Note: 
				Execution of a sell (buy) limit
				order corresponds to a buyer (seller) 
				initiated trade, i.e. Buy (Sell) trade.
										
						
## Orderbook File:		(Matrix of size: (Nx(4xNumberOfLevels)))
	
	Name: 	TICKER_Year-Month-Day_StartTime_EndTime_orderbook_LEVEL.csv
	
	Columns:
	
 	    1.) Ask Price 1: 	Level 1 Ask Price 	(Best Ask)
	    2.) Ask Size 1: 	Level 1 Ask Volume 	(Best Ask Volume)
	    3.) Bid Price 1: 	Level 1 Bid Price 	(Best Bid)
	    4.) Bid Size 1: 	Level 1 Bid Volume 	(Best Bid Volume)
	    5.) Ask Price 2: 	Level 2 Ask Price 	(2nd Best Ask)
	    ...

# Pipeline: Calibration → Integration

## 1) Ingest & Clean （读取与清洗）

- **message 文件**
  - Map `Event Type` → {Limit (L), Market (M), Cancel (C)}  
    将 `Event Type` 映射到 {限价 L、市价 M、撤单 C}。
  - Convert `Price` from integer (USD × 10,000) to USD  
    将价格从整数（美元×10000）还原为美元。
  - Convert timestamps to UTC or “seconds since midnight”  
    将时间戳转换为 UTC 或“自午夜起的秒数”。
  - Follow the LOBSTER Output spec for field definitions  
    字段定义以 LOBSTER 官方 Output 文档为准。

- **orderbook 文件**
  - Use `Ask/Bid Price i, Size i` to extract selected levels  
    使用 `Ask/Bid Price i, Size i` 提取所需档位。
  - Compute level-wise distributions and mean/variance  
    计算各档位的分布及均值/方差，用于深度与价差标定。

- **Data sanity checks 数据一致性检查**
  - Drop zero/missing prices, out-of-order timestamps, out-of-session rows  
    剔除价格为 0/缺失、时间倒序、交易时段外的记录。
  - Optionally winsorize extreme values  
    必要时对极端值做 winsorize 处理。

---

## 2) Empirical Estimates （经验量估计 → 驱动模拟器）

- **Arrival intensities & Hawkes parameters（到达强度与自激参数）**
  - Count by side/type: \(L^\pm, M^\pm, C^\pm\)  
    按方向与类型分组计数：\(L^\pm, M^\pm, C^\pm\)。
  - Fit multivariate exponential-kernel Hawkes via MLE/EM to estimate \(\mu, \alpha, \beta\)  
    用 MLE/EM 拟合多通道指数核 Hawkes，估计 \(\mu, \alpha, \beta\)。
  - Ensure branching ratio (spectral radius of \(\alpha/\beta\)) < 1 for stability  
    保证分支率（\(\alpha/\beta\) 的谱半径）< 1 以确保稳定。

- **Spread distribution（价差分布）**
  - From best bid/ask; optionally stratify by trade intensity or time of day  
    由最优 bid/ask 计算，即可按成交强度或分时分层。

- **Order-book depth profile（簿深度曲线）**
  - Aggregate mean/variance/quantiles per level  
    统计各档位的均值/方差/分位数，用于限价单档距与规模参考。

- **Cancellation probabilities（撤单概率）**
  - From cancellations and original submissions; condition on level or order age  
    基于撤单与最初提交量，按档位或订单龄估计条件撤单率。

---

## 3) Integration with Simulator / Matching Engine （接入模拟器 / 撮合引擎）

- **Event-to-order mapping（事件 → 下单映射）**
  - Drive a Poisson/Hawkes generator using empirical estimates  
    使用经验量驱动 Poisson/Hawkes 事件生成器。
  - Map to order instructions: L/M/C, side, price, size, timestamp, ID  
    映射为下单指令：L/M/C、方向、价格、数量、时间戳、ID。

- **Price & levels（价格与档距）**
  - Limit: place at `best ± level × tick` (level and tick from data)  
    限价：按 `best ± level × tick` 放置（level 与 tick 由数据校准）。
  - Market: execute against opposite best  
    市价：直接对撞对侧最优。

- **Higher realism (optional)（更仿真，可选）**
  - Sample level/size from empirical distributions  
    限价单的 level 与 size 按样本分布抽样。
  - Model cancellations as Poisson or Hawkes cancel channel  
    撤单建模为独立 Poisson 或 Hawkes 取消通道。
  - Use time-of-day parameter schedules (open/midday/close)  
    使用分时参数（开盘/午间/收盘）。

---

## Reference Tips （落地建议）

- **Units & scaling（单位与缩放）**
  - Price: USD × 10,000; Timestamp: sec→ns (per spec)  
    价格按美元×10000、时间戳精度依规范处理；先用小样本校验。

- **Train/validation split（训练/验证划分）**
  - Rolling windows; report OOS log-likelihood & diagnostics (QQ, ACF)  
    用滚动时间窗；报告外样本对数似然与诊断图（QQ、ACF）。

- **Stability & throttling（稳定与节流）**
  - Per-channel intensity caps; cooldowns if needed  
    为各通道加强度上限；必要时加入冷却期防止爆量。

- **Stylized facts（风格事实对比）**
  - Compare Poisson vs Hawkes: clustering, spread, depth, intensity–volatility, signature plot  
    对比 Poisson 与 Hawkes：簇集、价差、深度、强度–波动耦合、签名图。
